package com.example.android;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        EditText x = findViewById(R.id.number1);
        EditText y = findViewById(R.id.number2);

        Button z = (Button)findViewById(R.id.button1);

        TextView result = findViewById(R.id.textView1);

        z.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        int number1 = Integer.parseInt(x.getText().toString());
        int number2 = Integer.parseInt(y.getText().toString());
        int total = number1 + number2;
        result.setText(Integer.toString(number1+number2));
    }
});

}
}